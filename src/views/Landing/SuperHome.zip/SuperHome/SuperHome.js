import { Grid, Box, Button, Stack, Typography } from '@mui/material';
import { Link } from 'react-router-dom';
import Fade from 'react-reveal/Fade';
import React from 'react';
import './superhome.css';

const SuperHome = () => {
  return (
    <Box style={{ display: 'flex' }}>
      <Grid item xs={12} md={6} lg={6} className="p-rel" sx={{ height: '90vh' }}>
        <img
          style={{ width: '100%', height: '100%' }}
          src="https://i.pinimg.com/originals/dd/72/33/dd7233f13143566f5506fdf1571d60aa.gif"
          alt="fic"
        />
        <div className="centered">
          <Stack>
          <Fade left>
            <Typography style={{color: 'white',fontWeight: 'bold',fontSize:'40px'}} variant="h1" calssName="textdec">
              FICTION
            </Typography>
            <Link className="textdecoration" to="/home">
              <Button variant="contained" size="large">
                Get Started
              </Button>
            </Link>
            </Fade>
          </Stack>
        </div>
      </Grid>
      <Grid xs={12} md={6} lg={6} className="p-rel" sx={{ height: '90vh' }}>
        <img
          style={{ width: '100%', height: '100%' }}
          src="https://static.wixstatic.com/media/5cfe14_30977ca5f4d04cc2a8977a980baf19a9~mv2.gif"
          alt="fic"
        />
        <div className="centered">
          <Stack>
          <Fade right>
            <Typography  style={{color: 'white',fontWeight: 'bold',fontSize:'40px'}} variant="h1" calssName="textdec">
              Business
            </Typography>
            <Link className="textdecoration" to="/business">
              <Button variant="contained" size="large">
                Get Started
              </Button>
            </Link>
            </Fade>
          </Stack>
        </div>
      </Grid>
    </Box>
  );
};

export default SuperHome;
